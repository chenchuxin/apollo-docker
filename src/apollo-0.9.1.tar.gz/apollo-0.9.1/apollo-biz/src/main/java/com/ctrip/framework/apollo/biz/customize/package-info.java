/**
 * 携程内部的日志系统,第三方公司可删除
 */
package com.ctrip.framework.apollo.biz.customize;
