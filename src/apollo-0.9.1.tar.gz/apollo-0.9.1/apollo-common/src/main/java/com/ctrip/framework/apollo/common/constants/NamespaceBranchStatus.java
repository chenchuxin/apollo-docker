package com.ctrip.framework.apollo.common.constants;

public interface NamespaceBranchStatus {

  int DELETED = 0;

  int ACTIVE = 1;

  int MERGED = 2;

}
